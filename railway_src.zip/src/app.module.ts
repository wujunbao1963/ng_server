import { TopoMapModule } from './topomap/topomap.module';
import { Module, ValidationPipe } from '@nestjs/common';
import { APP_FILTER, APP_INTERCEPTOR, APP_PIPE } from '@nestjs/core';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HealthModule } from './health/health.module';
import { AuthModule } from './auth/auth.module';
import { CirclesModule } from './circles/circles.module';
import { EdgeDevicesModule } from './edge-devices/edge-devices.module';
import { DeviceAuthModule } from './device-auth/device-auth.module';
import { EventsIngestModule } from './events-ingest/events-ingest.module';
import { EventsReadModule } from './events-read/events-read.module';
import { EventsCollabModule } from './events-collab/events-collab.module';
import { EvidenceModule } from './evidence/evidence.module';
import { EdgeEventsModule } from './edge-events/edge-events.module';
import { IncidentReadModule } from './incident-read/incident-read.module';
import { EvidenceTicketsModule } from './evidence-tickets/evidence-tickets.module';
import { AdminModule } from './admin/admin.module';
import { NotificationsModule } from './notifications/notifications.module';
import { NgExceptionFilter } from './common/errors/ng-exception.filter';
import { InfraModule } from './infra/infra.module';
import { OutboxModule } from './common/outbox';
import { RequestIdInterceptor } from './infra/interceptors/request-id.interceptor';

// Phase 4: Server Sync (Ledger & Roles)
import { LedgerIngestModule } from './ledger-ingest/ledger-ingest.module';
import { RolesModule } from './roles/roles.module';

// Phase 6: RAHA Forwarding
import { RahaActionsModule } from './raha-actions/raha-actions.module';

@Module({
  imports: [
    // Infrastructure (global - provides ClockPort, PushProviderPort)
    InfraModule,
    
    // Outbox (global - provides OutboxService for reliable message delivery)
    OutboxModule,
    
    TopoMapModule, 
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env'],
    }),

    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        const dbUrl = config.get<string>('DATABASE_URL');
        if (!dbUrl) {
          throw new Error('DATABASE_URL is required (set it in .env)');
        }

        const sslEnabled = (config.get<string>('DB_SSL') ?? 'true') === 'true';
        const rejectUnauthorized = (config.get<string>('DB_SSL_REJECT_UNAUTHORIZED') ?? 'false') !== 'false';

        return {
          type: 'postgres',
          url: dbUrl,

          // Step 0: do not mutate remote DB
          synchronize: false,
          migrationsRun: false,

          // Step 2: enable entities (still no DB mutation because synchronize=false)
          autoLoadEntities: true,

          logging: ['error'],
          ssl: sslEnabled ? { rejectUnauthorized } : false,
        };
      },
    }),

    HealthModule,
    AuthModule,
    CirclesModule,
    EdgeDevicesModule,
    DeviceAuthModule,
    EventsIngestModule,
    EventsReadModule,
    EventsCollabModule,
    EdgeEventsModule,
    IncidentReadModule,
    EvidenceTicketsModule,
    AdminModule,
    EvidenceModule,
    NotificationsModule,
    
    // Phase 4: Server Sync (Ledger & Roles)
    LedgerIngestModule,
    RolesModule,
    
    // Phase 6: RAHA Forwarding
    RahaActionsModule,
  ],
  providers: [
    // Global interceptor for request tracking
    { provide: APP_INTERCEPTOR, useClass: RequestIdInterceptor },
    
    // Ensure contract-aligned error envelope and request validation are active
    // in BOTH normal bootstrap (main.ts) and e2e tests (which don't run main.ts).
    { provide: APP_FILTER, useClass: NgExceptionFilter },
    {
      provide: APP_PIPE,
      useValue: new ValidationPipe({
        transform: true,
        whitelist: true,
        forbidNonWhitelisted: true,
      }),
    },
  ],
})
export class AppModule {}
